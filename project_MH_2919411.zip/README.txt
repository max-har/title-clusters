1. The used dataset is available for download on GitHub: https://github.com/tategallery/collection.
2. For reproduction of the results, run "project_MH_2919411.py" with Python3.
